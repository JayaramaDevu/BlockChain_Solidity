#!/bin/bash

function one_line_pem {
    echo "`awk 'NF {sub(/\\n/, ""); printf "%s\\\\\\\n",$0;}' $1`"
}

function json_ccp {
    local PP=$(one_line_pem $4)
    local CP=$(one_line_pem $5)
    sed -e "s/\${ORG}/$1/" \
        -e "s/\${P0PORT}/$2/" \
        -e "s/\${CAPORT}/$3/" \
        -e "s#\${PEERPEM}#$PP#" \
        -e "s#\${CAPEM}#$CP#" \
        consortium/ccp-template.json
}

function yaml_ccp {
    local PP=$(one_line_pem $4)
    local CP=$(one_line_pem $5)
    sed -e "s/\${ORG}/$1/" \
        -e "s/\${P0PORT}/$2/" \
        -e "s/\${CAPORT}/$3/" \
        -e "s#\${PEERPEM}#$PP#" \
        -e "s#\${CAPEM}#$CP#" \
        consortium/ccp-template.yaml | sed -e $'s/\\\\n/\\\n          /g'
}

ORG="hospital1"
P0PORT=7051
CAPORT=1010
PEERPEM=consortium/crypto-config/peerOrganizations/hospital1/tlsca/tlsca.hospital1-cert.pem
CAPEM=consortium/crypto-config/peerOrganizations/hospital1/ca/ca.hospital1-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital1/connection-hospital1.json
echo "$(yaml_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital1/connection-hospital1.yaml

ORG="hospital2"
P0PORT=8051
CAPORT=1020
PEERPEM=consortium/crypto-config/peerOrganizations/hospital2/tlsca/tlsca.hospital2-cert.pem
CAPEM=consortium/crypto-config/peerOrganizations/hospital2/ca/ca.hospital2-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital2/connection-hospital2.json
echo "$(yaml_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital2/connection-hospital2.yaml

ORG="hospital3"
P0PORT=9051
CAPORT=1040
PEERPEM=consortium/crypto-config/peerOrganizations/hospital3/tlsca/tlsca.hospital3-cert.pem
CAPEM=consortium/crypto-config/peerOrganizations/hospital3/ca/ca.hospital3-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital3/connection-hospital3.json
echo "$(yaml_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital3/connection-hospital3.yaml

ORG="hospital4"
P0PORT=10051
CAPORT=1050
PEERPEM=consortium/crypto-config/peerOrganizations/hospital4/tlsca/tlsca.hospital4-cert.pem
CAPEM=consortium/crypto-config/peerOrganizations/hospital4/ca/ca.hospital4-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital4/connection-hospital4.json
echo "$(yaml_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM)" > consortium/crypto-config/peerOrganizations/hospital4/connection-hospital4.yaml
