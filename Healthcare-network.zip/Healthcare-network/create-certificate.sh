# To interact with Fabric-CA Server, we need another tool on our side. It can be either a Fabric-CA Client or Fabric SDKs. 
# Steps to follow to generate crypto materials:

# 1. Bring up the Fabric-CA Server which is used as the CA of that organization.
# 2. Use Fabric-CA Client to enroll a CA Admin.
# 3. With the CA Admin, use Fabric-CA Client to register and enroll every entity (peer, orderer, user, etc) one by one to the Fabric-CA Server.
# 4. Move the result material to the directory structure.

source scriptUtils.sh
export PATH=${PWD}/bin:$PATH

certificatesForHospital1() {
    echo
    echo "Enroll the CA admin"
    echo
    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/
    export FABRIC_CA_CLIENT_HOME=${PWD}/consortium/crypto-config/peerOrganizations/hospital1/

    # To go back to the previous folder
    # echo "${PWD%/[^/]*}"

    fabric-ca-client enroll -u https://admin:adminpw@localhost:1010 --caname ca.hospital1 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem
   
    # Create a config.yaml file to enable the OU identifiers, 
    # and keep the OU identifiers for each type of entity. 
    # They are peer, orderer, client and admin.
    echo 'NodeOUs:
    Enable: true
    ClientOUIdentifier:
        Certificate: cacerts/localhost-1010-ca-hospital1.pem
        OrganizationalUnitIdentifier: client
    PeerOUIdentifier:
        Certificate: cacerts/localhost-1010-ca-hospital1.pem
        OrganizationalUnitIdentifier: peer
    AdminOUIdentifier:
        Certificate: cacerts/localhost-1010-ca-hospital1.pem
        OrganizationalUnitIdentifier: admin
    OrdererOUIdentifier:
        Certificate: cacerts/localhost-1010-ca-hospital1.pem
        OrganizationalUnitIdentifier: orderer' >${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/config.yaml

    echo
    echo "Register peer0"
    echo
    fabric-ca-client register --caname ca.hospital1 --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem
    
    echo
    echo "Register peer1"
    echo
    fabric-ca-client register --caname ca.hospital1 --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    echo
    echo "Register user"
    echo
    fabric-ca-client register --caname ca.hospital1 --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    echo
    echo "Register the org admin"
    echo
    fabric-ca-client register --caname ca.hospital1 --id.name hospital1admin --id.secret hospital1adminpw --id.type admin --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    # Create a directory for peers
    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/peers

    ###########################################################################################################
    #  Peer 0
    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1

    echo
    echo "## Generate the peer0 msp"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1010 --caname ca.hospital1 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/msp --csr.hosts peer0.hospital1 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/msp/config.yaml

    echo
    echo "## Generate the peer0-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1010 --caname ca.hospital1 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls --enrollment.profile tls --csr.hosts peer0.hospital1 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/server.key

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/tlscacerts
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/tlscacerts/ca.crt

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/tlsca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/tlsca/tlsca.hospital1-cert.pem

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/ca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer0.hospital1/msp/cacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/ca/ca.hospital1-cert.pem
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/ca/

    ###########################################################################################################

    # Peer1

    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1

    echo
    echo "## Generate the peer1 msp"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1010 --caname ca.hospital1 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/msp --csr.hosts peer1.hospital1 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/msp/config.yaml

    echo
    echo "## Generate the peer1-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1010 --caname ca.hospital1 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls --enrollment.profile tls --csr.hosts peer1.hospital1 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/peers/peer1.hospital1/tls/server.key

    ###########################################################################################################

    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/users
    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/users/User1

    echo
    echo "## Generate the user msp"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:1010 --caname ca.hospital1 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/users/User1/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    mkdir -p consortium/crypto-config/peerOrganizations/hospital1/users/Admin@hospital1

    echo
    echo "## Generate the org admin msp"
    echo
    fabric-ca-client enroll -u https://hospital1admin:hospital1adminpw@localhost:1010 --caname ca.hospital1 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/users/Admin@hospital1/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital1/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital1/users/Admin@hospital1/msp/config.yaml
}

certificatesForHospital2() {
    echo
    echo "Enroll the CA admin"
    echo
    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/
    export FABRIC_CA_CLIENT_HOME=${PWD}/consortium/crypto-config/peerOrganizations/hospital2/


    fabric-ca-client enroll -u https://admin:adminpw@localhost:1020 --caname ca.hospital2 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem
   
    # Create a config.yaml file to enable the OU identifiers, 
    # and keep the OU identifiers for each type of entity. 
    # They are peer, orderer, client and admin.
    echo 'NodeOUs:
    Enable: true
    ClientOUIdentifier:
        Certificate: cacerts/localhost-1020-ca-hospital2.pem
        OrganizationalUnitIdentifier: client
    PeerOUIdentifier:
        Certificate: cacerts/localhost-1020-ca-hospital2.pem
        OrganizationalUnitIdentifier: peer
    AdminOUIdentifier:
        Certificate: cacerts/localhost-1020-ca-hospital2.pem
        OrganizationalUnitIdentifier: admin
    OrdererOUIdentifier:
        Certificate: cacerts/localhost-1020-ca-hospital2.pem
        OrganizationalUnitIdentifier: orderer' >${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/config.yaml

    echo
    echo "Register peer0"
    echo
    fabric-ca-client register --caname ca.hospital2 --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem
    
    echo
    echo "Register peer1"
    echo
    fabric-ca-client register --caname ca.hospital2 --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    echo
    echo "Register user"
    echo
    fabric-ca-client register --caname ca.hospital2 --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    echo
    echo "Register the org admin"
    echo
    fabric-ca-client register --caname ca.hospital2 --id.name hospital2admin --id.secret hospital2adminpw --id.type admin --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    # Create a directory for peers
    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/peers

    ###########################################################################################################
    #  Peer 0
    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2

    echo
    echo "## Generate the peer0 msp"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1020 --caname ca.hospital2 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/msp --csr.hosts peer0.hospital2 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/msp/config.yaml

    echo
    echo "## Generate the peer0-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1020 --caname ca.hospital2 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls --enrollment.profile tls --csr.hosts peer0.hospital2 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/server.key

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/tlscacerts
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/tlscacerts/ca.crt

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/tlsca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/tlsca/tlsca.hospital2-cert.pem

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/ca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer0.hospital2/msp/cacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/ca/ca.hospital2-cert.pem
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/ca/

    ###########################################################################################################

    # Peer1

    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2

    echo
    echo "## Generate the peer1 msp"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1020 --caname ca.hospital2 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/msp --csr.hosts peer1.hospital2 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/msp/config.yaml

    echo
    echo "## Generate the peer1-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1020 --caname ca.hospital2 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls --enrollment.profile tls --csr.hosts peer1.hospital2 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/peers/peer1.hospital2/tls/server.key

    ###########################################################################################################

    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/users
    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/users/User1@hospital2

    echo
    echo "## Generate the user msp"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:1020 --caname ca.hospital2 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/users/User1@hospital2/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    mkdir -p consortium/crypto-config/peerOrganizations/hospital2/users/Admin@hospital2

    echo
    echo "## Generate the org admin msp"
    echo
    fabric-ca-client enroll -u https://hospital2admin:hospital2adminpw@localhost:1020 --caname ca.hospital2 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/users/Admin@hospital2/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital2/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital2/users/Admin@hospital2/msp/config.yaml
}

certificatesForHospital3() {
    echo
    echo "Enroll the CA admin"
    echo
    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/
    export FABRIC_CA_CLIENT_HOME=${PWD}/consortium/crypto-config/peerOrganizations/hospital3/

    # To go back to the previous folder
    # echo "${PWD%/[^/]*}"

    fabric-ca-client enroll -u https://admin:adminpw@localhost:1040 --caname ca.hospital3 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem
   
    # Create a config.yaml file to enable the OU identifiers, 
    # and keep the OU identifiers for each type of entity. 
    # They are peer, orderer, client and admin.
    echo 'NodeOUs:
    Enable: true
    ClientOUIdentifier:
        Certificate: cacerts/localhost-1040-ca-hospital3.pem
        OrganizationalUnitIdentifier: client
    PeerOUIdentifier:
        Certificate: cacerts/localhost-1040-ca-hospital3.pem
        OrganizationalUnitIdentifier: peer
    AdminOUIdentifier:
        Certificate: cacerts/localhost-1040-ca-hospital3.pem
        OrganizationalUnitIdentifier: admin
    OrdererOUIdentifier:
        Certificate: cacerts/localhost-1040-ca-hospital3.pem
        OrganizationalUnitIdentifier: orderer' >${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/config.yaml

    echo
    echo "Register peer0"
    echo
    fabric-ca-client register --caname ca.hospital3 --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem
    
    echo
    echo "Register peer1"
    echo
    fabric-ca-client register --caname ca.hospital3 --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    echo
    echo "Register user"
    echo
    fabric-ca-client register --caname ca.hospital3 --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    echo
    echo "Register the org admin"
    echo
    fabric-ca-client register --caname ca.hospital3 --id.name hospital3admin --id.secret hospital3adminpw --id.type admin --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    # Create a directory for peers
    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/peers

    ###########################################################################################################
    #  Peer 0
    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3

    echo
    echo "## Generate the peer0 msp"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1040 --caname ca.hospital3 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/msp --csr.hosts peer0.hospital3 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/msp/config.yaml

    echo
    echo "## Generate the peer0-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1040 --caname ca.hospital3 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls --enrollment.profile tls --csr.hosts peer0.hospital3 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/server.key

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/tlscacerts
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/tlscacerts/ca.crt

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/tlsca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/tlsca/tlsca.hospital3-cert.pem

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/ca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer0.hospital3/msp/cacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/ca/ca.hospital3-cert.pem
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/ca/

    ###########################################################################################################

    # Peer1

    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3

    echo
    echo "## Generate the peer1 msp"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1040 --caname ca.hospital3 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/msp --csr.hosts peer1.hospital3 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/msp/config.yaml

    echo
    echo "## Generate the peer1-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1040 --caname ca.hospital3 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls --enrollment.profile tls --csr.hosts peer1.hospital3 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/peers/peer1.hospital3/tls/server.key

    ###########################################################################################################

    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/users
    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/users/User1@hospital3

    echo
    echo "## Generate the user msp"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:1040 --caname ca.hospital3 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/users/User1@hospital3/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    mkdir -p consortium/crypto-config/peerOrganizations/hospital3/users/Admin@hospital3

    echo
    echo "## Generate the org admin msp"
    echo
    fabric-ca-client enroll -u https://hospital3admin:hospital3adminpw@localhost:1040 --caname ca.hospital3 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/users/Admin@hospital3/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital3/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital3/users/Admin@hospital3/msp/config.yaml
}

certificatesForHospital4() {
    echo
    echo "Enroll the CA admin"
    echo
    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/
    export FABRIC_CA_CLIENT_HOME=${PWD}/consortium/crypto-config/peerOrganizations/hospital4/

    # To go back to the previous folder
    # echo "${PWD%/[^/]*}"

    fabric-ca-client enroll -u https://admin:adminpw@localhost:1050 --caname ca.hospital4 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem
   
    # Create a config.yaml file to enable the OU identifiers, 
    # and keep the OU identifiers for each type of entity. 
    # They are peer, orderer, client and admin.
    echo 'NodeOUs:
    Enable: true
    ClientOUIdentifier:
        Certificate: cacerts/localhost-1050-ca-hospital4.pem
        OrganizationalUnitIdentifier: client
    PeerOUIdentifier:
        Certificate: cacerts/localhost-1050-ca-hospital4.pem
        OrganizationalUnitIdentifier: peer
    AdminOUIdentifier:
        Certificate: cacerts/localhost-1050-ca-hospital4.pem
        OrganizationalUnitIdentifier: admin
    OrdererOUIdentifier:
        Certificate: cacerts/localhost-1050-ca-hospital4.pem
        OrganizationalUnitIdentifier: orderer' >${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/config.yaml

    echo
    echo "Register peer0"
    echo
    fabric-ca-client register --caname ca.hospital4 --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem
    
    echo
    echo "Register peer1"
    echo
    fabric-ca-client register --caname ca.hospital4 --id.name peer1 --id.secret peer1pw --id.type peer --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    echo
    echo "Register user"
    echo
    fabric-ca-client register --caname ca.hospital4 --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    echo
    echo "Register the org admin"
    echo
    fabric-ca-client register --caname ca.hospital4 --id.name hospital4admin --id.secret hospital4adminpw --id.type admin --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    # Create a directory for peers
    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/peers

    ###########################################################################################################
    #  Peer 0
    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4

    echo
    echo "## Generate the peer0 msp"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1050 --caname ca.hospital4 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/msp --csr.hosts peer0.hospital4 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/msp/config.yaml

    echo
    echo "## Generate the peer0-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer0:peer0pw@localhost:1050 --caname ca.hospital4 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls --enrollment.profile tls --csr.hosts peer0.hospital4 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/server.key

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/tlscacerts
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/tlscacerts/ca.crt

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/tlsca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/tlsca/tlsca.hospital4-cert.pem

    mkdir ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/ca
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer0.hospital4/msp/cacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/ca/ca.hospital4-cert.pem
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/ca/

    ###########################################################################################################

    # Peer1

    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4

    echo
    echo "## Generate the peer1 msp"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1050 --caname ca.hospital4 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/msp --csr.hosts peer1.hospital4 --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/msp/config.yaml

    echo
    echo "## Generate the peer1-tls certificates"
    echo
    fabric-ca-client enroll -u https://peer1:peer1pw@localhost:1050 --caname ca.hospital4 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls --enrollment.profile tls --csr.hosts peer1.hospital4 --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls/tlscacerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls/ca.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls/signcerts/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls/server.crt
    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls/keystore/* ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/peers/peer1.hospital4/tls/server.key

    ###########################################################################################################

    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/users
    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/users/User1@hospital4

    echo
    echo "## Generate the user msp"
    echo
    fabric-ca-client enroll -u https://user1:user1pw@localhost:1050 --caname ca.hospital4 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/users/User1@hospital4/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    mkdir -p consortium/crypto-config/peerOrganizations/hospital4/users/Admin@hospital4

    echo
    echo "## Generate the org admin msp"
    echo
    fabric-ca-client enroll -u https://hospital4admin:hospital4adminpw@localhost:1050 --caname ca.hospital4 -M ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/users/Admin@hospital4/msp --tls.certfiles ${PWD}/consortium/fabric-ca/hospital4/tls-cert.pem

    cp ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/msp/config.yaml ${PWD}/consortium/crypto-config/peerOrganizations/hospital4/users/Admin@hospital4/msp/config.yaml
}

certificatesForOrderer() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p consortium/crypto-config/ordererOrganizations/example.com

  export FABRIC_CA_CLIENT_HOME=${PWD}/consortium/crypto-config/ordererOrganizations/example.com

   
  fabric-ca-client enroll -u https://admin:adminpw@localhost:1030 --caname ca-orderer --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-1030-ca-orderer.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-1030-ca-orderer.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-1030-ca-orderer.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-1030-ca-orderer.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/config.yaml

  echo
  echo "Register orderer"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name orderer --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  echo
  echo "Register orderer2"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name orderer2 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  echo
  echo "Register orderer3"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name orderer3 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  echo
  echo "Register the orderer admin"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name ordererAdmin --id.secret ordererAdminpw --id.type admin --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/orderers
  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/orderers/example.com

  # ---------------------------------------------------------------------------
  #  Orderer

  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com

  echo
  echo "## Generate the orderer msp"
  echo
   
  fabric-ca-client enroll -u https://orderer:ordererpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp --csr.hosts orderer.example.com --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://orderer:ordererpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls --enrollment.profile tls --csr.hosts orderer.example.com --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/ca.crt
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/signcerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.crt
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/keystore/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.key

  mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/tlscacerts
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/ca
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/keystore/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/ca/

  # -----------------------------------------------------------------------
  #  Orderer 2

  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com

  echo
  echo "## Generate the orderer msp"
  echo
   
  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp --csr.hosts orderer2.example.com --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls --enrollment.profile tls --csr.hosts orderer2.example.com --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/ca.crt
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/signcerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/server.crt
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/keystore/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/server.key

  mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/tlscacerts
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/tlscacerts
  # cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # ---------------------------------------------------------------------------
  #  Orderer 3
  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com

  echo
  echo "## Generate the orderer msp"
  echo
   
  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp --csr.hosts orderer3.example.com --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls --enrollment.profile tls --csr.hosts orderer3.example.com --csr.hosts localhost --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/ca.crt
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/signcerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/server.crt
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/keystore/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/server.key

  mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/tlscacerts
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  mkdir ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/tlscacerts
  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # ---------------------------------------------------------------------------

  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/users
  mkdir -p consortium/crypto-config/ordererOrganizations/example.com/users/Admin@example.com

  echo
  echo "## Generate the admin msp"
  echo
   
  fabric-ca-client enroll -u https://ordererAdmin:ordererAdminpw@localhost:1030 --caname ca-orderer -M ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp --tls.certfiles ${PWD}/consortium/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/consortium/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/config.yaml

}

#certificate authorities compose file
COMPOSE_FILE_CA=docker/docker-compose-ca.yaml

IMAGE_TAG= docker-compose -f $COMPOSE_FILE_CA up -d 2>&1

sleep 6
docker ps

infoln "Creating Hospital1 Identities"
certificatesForHospital1

infoln "Creating Hospital2 Identities"
certificatesForHospital2

infoln "Creating Hospital3 Identities"
certificatesForHospital3

infoln "Creating Insurance Provider Identities"
certificatesForHospital4

infoln "Creating Orderer Org Identities"
certificatesForOrderer

infoln "Generating CCP files for all the Organizations"
consortium/ccp-generate.sh