'use strict';

var { Gateway, Wallets, DefaultEventHandlerStrategies, X509WalletMixin } = require('fabric-network');
const path = require('path');
const FabricCAServices = require('fabric-ca-client');
const fs = require('fs');

const util = require('util');

let ccpPath;
let configPath;

const getConnProfile = async (mspid) => {
    try {
        switch (mspid) {
            case 'Hospital1':
                ccpPath = path.resolve(__dirname, '..', '..', 'consortium', 'crypto-config', 'peerOrganizations', 'hospital1', 'connection-hospital1.json');
                configPath = path.resolve(__dirname, '..', '..', 'consortium', 'config', 'configHospital1.json');
                break;
            case 'Hospital2':
                ccpPath = path.resolve(__dirname, '..', '..', 'consortium', 'crypto-config', 'peerOrganizations', 'hospital2', 'connection-hospital2.json');
                configPath = path.resolve(__dirname, '..', '..', 'consortium', 'config', 'configHospital2.json');
                break;
            case 'Hospital3':
                ccpPath = path.resolve(__dirname, '..', '..', 'consortium', 'crypto-config', 'peerOrganizations', 'hospital3', 'connection-hospital3.json');
                configPath = path.resolve(__dirname, '..', '..', 'consortium', 'config', 'configHospital3.json');
                break;
            case 'Hospital4':
                ccpPath = path.resolve(__dirname, '..', '..', 'consortium', 'crypto-config', 'peerOrganizations', 'hospital4', 'connection-hospital4.json');
                configPath = path.resolve(__dirname, '..', '..', 'consortium', 'config', 'configHospital4.json');
                break;
            default:
                console.log('Sorry, couldn\'t find the connection profile');
        }

        const configJSON = await fs.readFileSync(configPath, 'utf8');
        const config = await JSON.parse(configJSON);
        const ccpJSON = await fs.readFileSync(ccpPath, 'utf8');
        const ccp = await JSON.parse(ccpJSON);
        let configObj = {};
        configObj.config = config;
        configObj.ccp = ccp;
        return configObj;
    } catch (error) {
        console.log(error)
        // throw Error(`Failed to return cpp`)
    }
}

const CreateUser = async (email, password, orgMSPID) => {
    if (!email || !password || !orgMSPID) {
        throw Error('Error! Please fill the registration form');
    }

    try {
        let configObj = await getConnProfile(orgMSPID);
        const walletPath = await getWalletLocation(orgMSPID)
        const wallet = await Wallets.newFileSystemWallet(walletPath);

        // Check to see if we've already enrolled the user.
        const userIdentity = await wallet.get(email);
        if (userIdentity) {
            console.log(`An identity for the user ${email} already exists in the wallet`);
            var response = {
                success: true,
                message: email + ' already exists!',
            };
            return response
        }

        // Check to see if we've already enrolled the admin user.
        let adminIdentity = await wallet.get(configObj.config.appAdmin);
        if (!adminIdentity) {
            console.log('An identity for the admin user "admin" does not exist in the wallet');
            await enrollAdmin(orgMSPID, configObj.ccp);
            adminIdentity = await wallet.get('admin');
            console.log("Admin Enrolled Successfully")
        }

        const connectOptions = {
            wallet, identity: configObj.config.appAdmin, discovery: configObj.config.gatewayDiscovery
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(configObj.ccp, connectOptions);

        // Get the CA client object from the gateway for interacting with the CA.
        // const caURL = await getCaUrl(orgMSPID, configObj.ccp)
        const caName = await getCAName(orgMSPID);
        const caURL = configObj.ccp.certificateAuthorities[caName].url;

        const ca = new FabricCAServices(caURL);

        // build a user object for authenticating with the CA
        const provider = wallet.getProviderRegistry().getProvider(adminIdentity.type);
        const adminUser = await provider.getUserContext(adminIdentity, 'admin');

        // Register the user, enroll the user, and import the new identity into the wallet.
        const secret = await ca.register({ enrollmentID: email, role: 'client' }, adminUser);
        const enrollment = await ca.enroll({ enrollmentID: email, enrollmentSecret: secret });
        const x509Identity = await createIdentity(enrollment, orgMSPID)
        await wallet.put(email, x509Identity);

        console.log(`Successfully registered and enrolled admin user ${email} and imported it into the wallet`);

        var response = {
            success: true,
            message: email + ' enrolled Successfully',
        };
        return response

    } catch (error) {
        // console.log(error)
        return error.message
    }
}

const getCAName = async (org) => {
    var caName = 'ca.' + org.toLowerCase();
    return caName;
}

const createIdentity = async (enrollment, orgMSPID) => {
    let x509Identity;
    x509Identity = {
        credentials: {
            certificate: enrollment.certificate,
            privateKey: enrollment.key.toBytes(),
        },
        mspId: orgMSPID + 'MSP',
        type: 'X.509',

    };
    return x509Identity;
}

const getCCP = async (org) => {
    let ccpPath;
    var peer_folder = ''
    if (org == 'Hospital1-4') {
        peer_folder = 'hospital1-4'
    } else {
        peer_folder = org.toLowerCase();
    }

    ccpPath = path.resolve(__dirname, '..', '..', 'consortium', 'crypto-config', 'peerOrganizations', peer_folder, 'connection-' + peer_folder + '.json');

    const ccpJSON = fs.readFileSync(ccpPath, 'utf8')
    const ccp = JSON.parse(ccpJSON);
    return ccp
}

const getCaUrl = async (org, ccp) => {
    const caName = await getCAName(org);
    const caURL = ccp.certificateAuthorities[caName].url;
    return caURL
}

const getWalletLocation = async (org) => {
    let walletPath = path.join(process.cwd(), org.toLowerCase() + '-wallet');
    return walletPath
}

const getAffiliation = async (org) => {
    return org == "Org1" ? 'org1.department1' : 'org2.department1'
}

const isUserRegistered = async (username, userHospital1) => {
    const walletPath = await getWalletLocation(userHospital1)
    console.log(walletPath)
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    const userIdentity = await wallet.get(username);
    if (userIdentity) {
        console.log(`An identity for the user ${username} exists in the wallet`);
        return true
    }
    return false
}

const enrollAdmin = async (org, ccp) => {

    console.log('calling enroll Admin method')

    try {
        const caName = await getCAName(org);
        const caInfo = await ccp.certificateAuthorities[caName]; //ccp.certificateAuthorities['ca.hospital11.example.com'];
        const caTLSCACerts = caInfo.tlsCACerts.pem;
        const ca = new FabricCAServices(caInfo.url, { trustedRoots: caTLSCACerts, verify: false }, caInfo.caName);

        // Create a new file system based wallet for managing identities.
        const walletPath = await getWalletLocation(org) //path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the admin user.
        const identity = await wallet.get('admin');
        if (identity) {
            console.log('An identity for the admin user "admin" already exists in the wallet');
            return;
        }

        // Enroll the admin user, and import the new identity into the wallet.
        const enrollment = await ca.enroll({ enrollmentID: 'admin', enrollmentSecret: 'adminpw' });
        const x509Identity = await createIdentity(enrollment, org)

        await wallet.put('admin', x509Identity);
        console.log('Successfully enrolled admin user "admin" and imported it into the wallet');
        return
    } catch (error) {
        console.error(`Failed to enroll admin user "admin": ${error}`);
    }
}

const registerAndGerSecret = async (username, userHospital1) => {
    let ccp = await getCCP(userHospital1)

    const caURL = await getCaUrl(userHospital1, ccp)
    const ca = new FabricCAServices(caURL);

    const walletPath = await getWalletPath(userHospital1)
    const wallet = await Wallets.newFileSystemWallet(walletPath);
    console.log(`Wallet path: ${walletPath}`);

    const userIdentity = await wallet.get(username);
    if (userIdentity) {
        console.log(`An identity for the user ${username} already exists in the wallet`);
        var response = {
            success: true,
            message: username + ' enrolled Successfully',
        };
        return response
    }

    // Check to see if we've already enrolled the admin user.
    let adminIdentity = await wallet.get('admin');
    if (!adminIdentity) {
        console.log('An identity for the admin user "admin" does not exist in the wallet');
        await enrollAdmin(userHospital1, ccp);
        adminIdentity = await wallet.get('admin');
        console.log("Admin Enrolled Successfully")
    }

    // build a user object for authenticating with the CA
    const provider = wallet.getProviderRegistry().getProvider(adminIdentity.type);
    const adminUser = await provider.getUserContext(adminIdentity, 'admin');
    let secret;
    try {
        // Register the user, enroll the user, and import the new identity into the wallet.
        secret = await ca.register({ affiliation: await getAffiliation(userHospital1), enrollmentID: username, role: 'client' }, adminUser);
        // const secret = await ca.register({ affiliation: 'hospital11.department1', enrollmentID: username, role: 'client', attrs: [{ name: 'role', value: 'approver', ecert: true }] }, adminUser);

    } catch (error) {
        return error.message
    }

    var response = {
        success: true,
        message: username + ' enrolled Successfully',
        secret: secret
    };
    return response

}

module.exports = {
    getConnProfile: getConnProfile,
    getCCP: getCCP,
    getWalletLocation: getWalletLocation,
    isUserRegistered: isUserRegistered,
    registerAndGerSecret: registerAndGerSecret,
    CreateUser: CreateUser
}
