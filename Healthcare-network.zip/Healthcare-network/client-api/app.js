'use strict';
const log4js = require('log4js');
const logger = log4js.getLogger('Hospital1-sample');
const bodyParser = require('body-parser');
const http = require('http')
const util = require('util');
const express = require('express')
const app = express();
const expressJWT = require('express-jwt');
const jwt = require('jsonwebtoken');
const bearerToken = require('express-bearer-token');
const cors = require('cors');
const constants = require('./config/constants.json')

const host = process.env.HOST || constants.host;
const port = process.env.PORT || constants.port;

const helper = require('./app/helper')
const invoke = require('./app/invoke')
const query = require('./app/query')

app.options('*', cors());
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
// set secret variable
app.set('secret', 'thisismysecret');
app.use(expressJWT({
    secret: 'thisismysecret', algorithms: ['HS256'] //setting the signing algorithm as "HMAC SHA256" 
}).unless({
    path: ['/users', '/users/login', '/register', '/validateUser', '/createUser']
}));
app.use(bearerToken());

logger.level = 'debug';

app.use((req, res, next) => {
    logger.debug('New req for %s', req.originalUrl);
    if (req.originalUrl.indexOf('/users') >= 0 || req.originalUrl.indexOf('/users/login') >= 0 || req.originalUrl.indexOf('/createUser') >= 0 || req.originalUrl.indexOf('/validateUser') >= 0 || req.originalUrl.indexOf('/register') >= 0) {
        return next();
    }
    var token = req.token;
    jwt.verify(token, app.get('secret'), (err, decoded) => {
        if (err) {
            console.log(`Error ================:${err}`)
            res.send({
                success: false,
                message: 'Failed to authenticate token. Make sure to include the ' +
                    'token returned from /users call in the authorization header ' +
                    ' as a Bearer token'
            });
            res.json({ success: false, message: message });
            return;
        } else {
            req.useremail = decoded.email;
            req.orgname = decoded.mspid;
            logger.debug(util.format('Decoded from JWT token: username - %s, hospital1name - %s', decoded.email, decoded.mspid));
            return next();
        }
    });
});

var server = http.createServer(app).listen(port, function () { console.log(`Server started on ${port}`) });
logger.info('****************** SERVER STARTED ************************');
logger.info('***************  http://%s:%s  ******************', host, port);
server.timeout = 240000;

function getErrorMessage(field) {
    var response = {
        success: false,
        message: field + ' field is missing or Invalid in the request'
    };
    return response;
}

// Register a new user to the hospital1 fabric network
app.post('/createUser', async (req, res) => {
    var emailid = req.body.emailid;
    var password = req.body.password;
    var lastName = req.body.lastName;
    var mspid = req.body.mspid;
    var hospital1_affiliation = req.body.hospital1_affiliate;


    logger.debug('End point : /createUser');
    logger.debug('Email id : ' + emailid);
    logger.debug('Msp id: ' + mspid);


    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        email: emailid,
        mspid: mspid
    }, app.get('secret'));

    let response = await helper.CreateUser(emailid, password, mspid)

    if (response && typeof response !== 'string') {
        logger.debug('Successfully registered the username %s', emailid);
        response.token = token;
        res.json(response);
    } else {
        logger.debug('Failed to register the username %s ', emailid);
        res.json({ success: false, message: response });
    }

});

// Register and enroll user
app.post('/users', async function (req, res) {
    var username = req.body.username;
    var hospital1Name = req.body.hospital1Name;
    logger.debug('End point : /users');
    logger.debug('User name : ' + username);
    logger.debug('Hospital1 name  : ' + hospital1Name);
    if (!username) {
        res.json(getErrorMessage('\'username\''));
        return;
    }
    if (!hospital1Name) {
        res.json(getErrorMessage('\'hospital1Name\''));
        return;
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        username: username,
        hospital1Name: hospital1Name
    }, app.get('secret'));

    let response = await helper.getRegisteredUser(username, hospital1Name, true);

    logger.debug('-- returned from registering the username %s for hospital1 %s', username, hospital1Name);
    if (response && typeof response !== 'string') {
        logger.debug('Successfully registered the username %s for hospital1 %s', username, hospital1Name);
        response.token = token;
        res.json(response);
    } else {
        logger.debug('Failed to register the username %s for hospital1 %s with::%s', username, hospital1Name, response);
        res.json({ success: false, message: response });
    }

});

// Register and enroll user
app.post('/register', async function (req, res) {
    var username = req.body.username;
    var hospital1Name = req.body.hospital1Name;
    logger.debug('End point : /users');
    logger.debug('User name : ' + username);
    logger.debug('Hospital1 name  : ' + hospital1Name);
    if (!username) {
        res.json(getErrorMessage('\'username\''));
        return;
    }
    if (!hospital1Name) {
        res.json(getErrorMessage('\'hospital1Name\''));
        return;
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        username: username,
        hospital1Name: hospital1Name
    }, app.get('secret'));

    console.log(token)

    let response = await helper.registerAndGerSecret(username, hospital1Name);

    logger.debug('-- returned from registering the username %s for hospital1 %s', username, hospital1Name);
    if (response && typeof response !== 'string') {
        logger.debug('Successfully registered the username %s for hospital1 %s', username, hospital1Name);
        response.token = token;
        res.json(response);
    } else {
        logger.debug('Failed to register the username %s for hospital1 %s with::%s', username, hospital1Name, response);
        res.json({ success: false, message: response });
    }

});

//Validate the user
app.post('/validateUser', async function (req, res) {
    var email = req.body.emailid;
    var org = req.body.org;
    console.log(email)
    logger.debug('End point : /validateUser');
    logger.debug('Email id : ' + email);
    logger.debug('Org : ' + org);

    if (!email) {
        res.json(getErrorMessage('\'email\''));
        return;
    }

    try {
        var token = jwt.sign({
            exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
            email: email,
            mspid: org
        }, app.get('secret'));

        let isUserRegistered = await helper.isUserRegistered(email, org);

        if (isUserRegistered) {
            var res_msg = {
                success: true,
                token: token,
                message: 'Registerd user'
            };
            res.json(res_msg)

        } else {
            var res_msg = {
                success: false,
                token: '',
                message: `User with Emailid ${email} is not registered, Please register first.`
            };
            // res_msg.success = false;
            // res_msg.message = `User with Emailid ${email} is not registered, Please register first.`
            res.json(res_msg);
        }
    } catch (error) {
        console.log(error)
    }

});

// Login and get jwt
app.post('/users/login', async function (req, res) {
    var username = req.body.username;
    var hospital1Name = req.body.hospital1Name;
    logger.debug('End point : /users');
    logger.debug('User name : ' + username);
    logger.debug('Hospital1 name  : ' + hospital1Name);
    if (!username) {
        res.json(getErrorMessage('\'username\''));
        return;
    }
    if (!hospital1Name) {
        res.json(getErrorMessage('\'hospital1Name\''));
        return;
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        username: username,
        hospital1Name: hospital1Name
    }, app.get('secret'));

    let isUserRegistered = await helper.isUserRegistered(username, hospital1Name);

    if (isUserRegistered) {
        res.json({ success: true, message: { token: token } });

    } else {
        res.json({ success: false, message: `User with username ${username} is not registered with ${hospital1Name}, Please register first.` });
    }
});

// Register Patient
app.post('/patients/register', async function (req, res) {
    var channelName = req.body.channelname;
    var chaincodeName = req.body.chaincodeName;
    var patientname = req.body.patientName;
    var hospital1Name = req.body.hospital1Name;
    logger.debug('End point : /users');
    logger.debug('Patient name : ' + patientname);
    logger.debug('Hospital1 name  : ' + hospital1Name);
    logger.debug('Channel name  : ' + channelName);
    logger.debug('Chaincode name  : ' + chaincodeName);
    var fcn = "RegisterPatient";

    if (!patientname) {
        res.json(getErrorMessage('\'patientname\''));
        return;
    }
    if (!hospital1Name) {
        res.json(getErrorMessage('\'hospital1Name\''));
        return;
    }


    let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, patientname, hospital1Name);
    console.log(`message result is : ${message}`)

    const response_payload = {
        result: message,
        error: null,
        errorData: null
    }
    res.send(response_payload);
});

// Invoke transaction on chaincode on target peers
app.post('/channels/:channelName/chaincodes/:chaincodeName', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        var peers = req.body.peers;
        var chaincodeName = req.params.chaincodeName;
        var channelName = req.params.channelName;
        var fcn = req.body.fcn;
        var args = req.body.args;
        var transient = req.body.transient;
        var orgName = req.orgname;
        var userEmail = req.useremail;

        logger.debug(`Transient data is ;${transient}`)
        logger.debug('channelName  : ' + channelName);
        logger.debug('chaincodeName : ' + chaincodeName);
        logger.debug('fcn  : ' + fcn);
        logger.debug('args  : ' + args);
        logger.debug('org  : ' + orgName);

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }
        if (!args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }

        let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, userEmail, orgName, transient);
        console.log(`message result is : ${message.message}`)
        if (message.message.startsWith('Successfully ')) {
            const response_payload = {
                success: true,
                result: message,
                // error: null,
                errorData: null
            }
            res.send(response_payload);
        } else {
            const response_payload = {
                success: false,
                result: null,
                // error: error.name,
                errorData: message
            }
            res.send(response_payload)
        }



    } catch (error) {
        const response_payload = {
            success: false,
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

app.get('/channels/:channelName/chaincodes/:chaincodeName', async function (req, res) {
    try {
        logger.debug('==================== QUERY BY CHAINCODE ==================');
        var channelName = req.params.channelName;
        var chaincodeName = req.params.chaincodeName;
        console.log(`chaincode name is :${chaincodeName}`)
        let args = req.query.args;
        let fcn = req.query.fcn;
        // let fcn = req.body.fcn;
        let peer = req.query.peer;

        args = args.replace(/'/g, '"');
        // args = JSON.parse(args);
        logger.debug(args);

        logger.debug('channelName : ' + channelName);
        logger.debug('chaincodeName : ' + chaincodeName);
        logger.debug('fcn : ' + fcn);
        logger.debug('args : ' + args);

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }
        if (!args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }
        console.log('args==========', args);
        // args = args.replace(/'/g, '"');
        // args = JSON.parse(args);
  
        let message = await query.query(channelName, chaincodeName, args, fcn, req.useremail, req.orgname);

        const response_payload = {
            result: message,
            error: null,
            errorData: null
        }

        res.send(response_payload);
    } catch (error) {
        const response_payload = {
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

