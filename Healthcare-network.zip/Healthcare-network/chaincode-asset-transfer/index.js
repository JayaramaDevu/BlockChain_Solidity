/*
 * Copyright IBM Corp. All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const patientInfo = require('./lib/patientInfo');

module.exports.PatientInfo = patientInfo;
module.exports.contracts = [patientInfo];